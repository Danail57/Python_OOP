class ProductRepository:
    def __init__(self):
        self.products = []

    def add(self, product):
        self.products.append(product)

    def find(self, product_name):
        product = [p for p in self.products if p.name == product_name][0]
        return product

    def remove(self, product_name):
        product = [p for p in self.products if p.name == product_name][0]
        self.products.remove(product)

    def __repr__(self):
        result = ''
        for p in self.products:
            result += f'{p.name}: {p.quantity}\n'

