from reptile import Reptile


class Snake(Reptile):
    pass