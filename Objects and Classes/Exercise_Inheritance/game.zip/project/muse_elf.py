from elf import Elf


class MuseELf(Elf):
    pass