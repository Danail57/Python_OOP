from dark_wizard import DarkWizard


class SoulMaster(DarkWizard):
    pass