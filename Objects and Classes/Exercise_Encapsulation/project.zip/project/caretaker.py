from project.worker import Worker


class CareTaker(Worker):
    pass