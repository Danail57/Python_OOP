class Food:

    def __init__(self, expiration_date):
        self.expiration = expiration_date