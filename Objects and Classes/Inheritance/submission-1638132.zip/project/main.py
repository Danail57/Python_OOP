from project.animal import Animal
from project.dog import Dog

a = Animal()
d = Dog()

print(a.eat())
print(d.bark())
print(d.eat())