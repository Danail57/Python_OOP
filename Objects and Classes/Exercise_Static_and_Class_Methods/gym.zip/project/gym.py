class Gym:
    def __init__(self):
        self.customers = []
        self.trainers = []
        self.equipment = []
        self.plans = []
        self.subscriptions = []

    def add_customer(self, customer):
        if customer not in self.customers:
            self.customers.append(customer)

    def add_trainer(self, trainer):
        if trainer not in self.trainers:
            self.trainers.append(trainer)

    def add_equipment(self, equipment):
        if equipment not in self.equipment:
            self.equipment.append(equipment)

    def add_plan(self, plan):
        if plan not in self.plans:
            self.plans.append(plan)

    def add_subscription(self, subscription):
        if subscription not in self.subscriptions:
            self.subscriptions.append(subscription)

    def subscription_info(self, subscription_id: int):
        # Намираме подписката
        subscription = next((s for s in self.subscriptions if s.subscription_id == subscription_id), None)
        if not subscription:
            return "Subscription not found"

        customer = next((c for c in self.customers if c.personal_id == subscription.customer_id), None)
        trainer = next((t for t in self.trainers if t.trainer_id == subscription.trainer_id), None)
        plan = next((p for p in self.plans if p.plan_id == subscription.exercise_id), None)
        equipment = next((e for e in self.equipment if e.equipment_id == plan.equipment_id), None) if plan else None

        info_list = [str(subscription)]
        if customer:
            info_list.append(str(customer))
        if trainer:
            info_list.append(str(trainer))
        if equipment:
            info_list.append(str(equipment))
        if plan:
            info_list.append(str(plan))

        return "\n".join(info_list)
