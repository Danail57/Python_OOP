class Customer:
    _id = 1
    def __init__(self, name: str, address: str, email: str):
        self.name = name
        self.address = address
        self.email = email
        Customer._id += 1
        self.personal_id = Customer._id

    @classmethod
    def get_next_id(cls):
        return cls._id

    def __repr__(self) -> str:
        return f"Customer <{self._id}> {self.name}; Address: {self.address}; Email: {self.email}"